Instrukcja:

1. Wgraj całą zawartość na GitHub (foldery: admin, uploads + pliki index.html i style.css).
2. W Netlify:
   - Włącz Identity i Git Gateway.
   - Skonfiguruj Continuous Deployment.
3. W panelu admin (/admin) dodawaj nowe zdjęcia z tytułami.
4. Netlify CMS stworzy wpisy i strona automatycznie wyświetli nowe zdjęcia!

Uwaga: początkowo musisz stworzyć pierwszy wpis ręcznie, aby wygenerować plik JSON.
